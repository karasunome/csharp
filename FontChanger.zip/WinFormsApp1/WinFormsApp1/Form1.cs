﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        
        private int fondId = 0;
        private bool timerState = false;

        private string getNextFontName()
        {
            InstalledFontCollection installedFontCollection = new InstalledFontCollection();

            // Get the array of FontFamily objects.
            FontFamily[] fontFamilies = installedFontCollection.Families;

            // The loop below creates a large string that is a comma-separated
            // list of all font family names.
            fondId++;
            string familyName = fontFamilies[fondId].Name;

            return familyName;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //textBox1.Font = new Font(getNextFontName(), 18);
            if (timerState)
            {
                timerState = false;
                button1.Text = "durdur";
                timer1.Start();
            }
            else
            {
                timerState = true;
                button1.Text = "başla";
                timer1.Stop();
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            textBox1.Font = new Font(getNextFontName(), 18);
        }
    }
}
